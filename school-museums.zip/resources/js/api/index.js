import instance from './instance'
import mapAPI from './map'

export default {
    mapAPI: mapAPI(instance)
}