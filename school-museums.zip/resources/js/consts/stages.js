const stages = {
    city: 'CITY',
    district: 'DISTRICT',
    museum: 'MUSEUM',
    search: 'SEARCH'
}
export default stages