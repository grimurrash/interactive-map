<template>
  <header class="map-header">
    <a href="https://patriotsport.moscow/" class="map-header__logo">
      <img alt="logo" width="30" height="30" src="public/favicon.png"/>
      <p class="map-header__logo-text">
        <span>Московский центр</span>
        <br>
        <span>Патриот спорт</span>
      </p>
    </a>
    <h2 class="map-header__title">
      <span>Школьные</span>
      <span>музеи</span>
    </h2>
  </header>
</template>

<script>
export default {
  name: "MapHeader"
}
</script>

<style lang="scss">
</style>
