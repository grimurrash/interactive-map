<template>
  <div class="error">
    <div class="code">404</div>
    <h1>Страница не найдена</h1>
    <h4><router-link class=".home-link" to="/">Вернуться на главную</router-link></h4>
  </div>
</template>

<script>
export default {
  name: "NotFoundPage"
}
</script>

<style lang="scss" scoped="">

</style>
