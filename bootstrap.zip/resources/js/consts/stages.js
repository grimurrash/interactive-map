const stages = {
    city: 'CITY',
    district: 'DISTRICT',
    subject: 'SUBJECT',
    search: 'SEARCH'
}
export default stages